"""
Tests for BugAttachmentCRUD operations.
"""

import pytest

from bug_lifecycle_engine.crud import BugAttachmentCRUD
from tests.conftest import seed_user, seed_bug


class TestBugAttachmentCRUD:
    """Test attachment CRUD operations."""

    def test_create_minimal_attachment(self, session):
        """Test creating a basic attachment."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugAttachmentCRUD(session)
        attachment = crud.create(
            bug_id=bug.id,
            file_name="screenshot.png",
            file_path="/uploads/screenshot.png",
            uploaded_by="USR-000001"
        )
        
        assert attachment.id is not None
        assert attachment.bug_id == bug.id
        assert attachment.file_name == "screenshot.png"
        assert attachment.file_path == "/uploads/screenshot.png"
        assert attachment.uploaded_by == "USR-000001"
        assert attachment.file_type is None
        assert attachment.file_size is None
        assert attachment.is_deleted is False
        assert attachment.uploaded_at is not None

    def test_create_attachment_with_metadata(self, session):
        """Test creating an attachment with file metadata."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugAttachmentCRUD(session)
        attachment = crud.create(
            bug_id=bug.id,
            file_name="error_log.txt",
            file_path="/uploads/error_log.txt",
            uploaded_by="USR-000001",
            file_type="text/plain",
            file_size=1024
        )
        
        assert attachment.file_type == "text/plain"
        assert attachment.file_size == 1024

    def test_list_attachments_by_bug(self, session):
        """Test listing attachments for a specific bug."""
        seed_user(session)
        bug1 = seed_bug(session)
        bug2 = seed_bug(session)
        
        crud = BugAttachmentCRUD(session)
        
        # Create attachments for both bugs
        att1 = crud.create(bug1.id, "file1.png", "/uploads/file1.png", "USR-000001")
        att2 = crud.create(bug1.id, "file2.log", "/uploads/file2.log", "USR-000001")
        att3 = crud.create(bug2.id, "file3.jpg", "/uploads/file3.jpg", "USR-000001")
        
        # List attachments for bug1
        bug1_attachments = crud.list_by_bug(bug1.id)
        assert len(bug1_attachments) == 2
        
        attachment_ids = [a.id for a in bug1_attachments]
        assert att1.id in attachment_ids
        assert att2.id in attachment_ids
        assert att3.id not in attachment_ids
        
        # Verify ordering (newest first)
        assert bug1_attachments[0].uploaded_at >= bug1_attachments[1].uploaded_at

    def test_soft_delete_attachment(self, session):
        """Test soft deleting an attachment."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugAttachmentCRUD(session)
        attachment = crud.create(
            bug_id=bug.id,
            file_name="to_delete.pdf",
            file_path="/uploads/to_delete.pdf",
            uploaded_by="USR-000001"
        )
        
        # Delete the attachment
        deleted = crud.soft_delete(attachment.id, "USR-000001")
        
        assert deleted.is_deleted is True
        
        # Verify it doesn't appear in normal listing
        attachments = crud.list_by_bug(bug.id, include_deleted=False)
        assert len(attachments) == 0
        
        # But appears when including deleted
        attachments_with_deleted = crud.list_by_bug(bug.id, include_deleted=True)
        assert len(attachments_with_deleted) == 1

    def test_get_nonexistent_attachment(self, session):
        """Test getting a non-existent attachment."""
        crud = BugAttachmentCRUD(session)
        assert crud.get("NONEXISTENT") is None
        
        with pytest.raises(ValueError, match="not found"):
            crud.get_or_raise("NONEXISTENT")

    def test_pagination(self, session):
        """Test attachment pagination."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugAttachmentCRUD(session)
        
        # Create 5 attachments
        for i in range(5):
            crud.create(
                bug.id, 
                f"file{i}.txt", 
                f"/uploads/file{i}.txt", 
                "USR-000001"
            )
        
        # Test pagination
        page1 = crud.list_by_bug(bug.id, skip=0, limit=3)
        page2 = crud.list_by_bug(bug.id, skip=3, limit=3)
        
        assert len(page1) == 3
        assert len(page2) == 2
        
        # Ensure no overlap
        page1_ids = [a.id for a in page1]
        page2_ids = [a.id for a in page2]
        assert not set(page1_ids).intersection(set(page2_ids))

    def test_file_size_validation(self, session):
        """Test that large file sizes are handled correctly."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugAttachmentCRUD(session)
        attachment = crud.create(
            bug_id=bug.id,
            file_name="large_file.zip",
            file_path="/uploads/large_file.zip",
            uploaded_by="USR-000001",
            file_size=1024 * 1024 * 10  # 10MB
        )
        
        assert attachment.file_size == 1024 * 1024 * 10

    def test_special_characters_in_filename(self, session):
        """Test handling files with special characters."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugAttachmentCRUD(session)
        attachment = crud.create(
            bug_id=bug.id,
            file_name="test file (copy) #2.txt",
            file_path="/uploads/test%20file%20(copy)%20%232.txt",
            uploaded_by="USR-000001"
        )
        
        assert attachment.file_name == "test file (copy) #2.txt"
        assert attachment.file_path == "/uploads/test%20file%20(copy)%20%232.txt"