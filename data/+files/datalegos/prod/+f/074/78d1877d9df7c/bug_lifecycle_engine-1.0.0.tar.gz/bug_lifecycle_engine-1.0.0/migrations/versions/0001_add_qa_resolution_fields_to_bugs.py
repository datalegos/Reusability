"""Add QA resolution tracking fields to bugs table.

Adds two nullable columns to support QA-side resolution tracking:
  - qa_verified_at  : timestamp when a QA engineer marked the fix as verified
  - qa_verified_by  : user id of the QA engineer who verified the fix

Both columns are nullable and have no server default, so the migration is
safe to apply to a populated table without downtime or data backfill.

Revision ID: 0001
Revises:
Create Date: 2026-08-26

POLICY: ADDITIVE ONLY — see migrations/README for rules.
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "bugs",
        sa.Column(
            "qa_verified_at",
            sa.DateTime(timezone=True),
            nullable=True,
            comment="Timestamp when QA engineer verified the bug fix",
        ),
    )
    op.add_column(
        "bugs",
        sa.Column(
            "qa_verified_by",
            sa.String(20),
            sa.ForeignKey("users.id"),
            nullable=True,
            comment="User ID of QA engineer who verified the fix",
        ),
    )


def downgrade() -> None:
    op.drop_column("bugs", "qa_verified_by")
    op.drop_column("bugs", "qa_verified_at")
