"""
SQLAlchemy engine / session factory for bug-lifecycle-engine.
Connects to the existing worky Postgres instance — no DB container is created here.
"""

from contextlib import contextmanager
from typing import Generator

from sqlalchemy import create_engine as _create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from .settings import get_settings


def get_engine() -> Engine:
    """Build a SQLAlchemy engine from environment variables."""
    settings = get_settings()
    return _create_engine(
        settings.database_url,
        pool_size=settings.DATABASE_POOL_SIZE,
        max_overflow=settings.DATABASE_MAX_OVERFLOW,
        pool_pre_ping=True,
        future=True,
    )


@contextmanager
def get_session(engine: Engine) -> Generator[Session, None, None]:
    """Yield a SQLAlchemy session, committing on success and rolling back on error."""
    SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
    session: Session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
