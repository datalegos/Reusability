"""
ORM models for bug-lifecycle-engine.

Maps onto EXISTING worky tables — no DDL is issued by this package
(Alembic handles any additive migrations separately).

Writable:
  - bugs

Read-only FK stubs (never written to from this package):
  - users
  - test_runs
  - test_cases
  - clients
  - programs
  - projects
  - usecases
  - user_stories
  - tasks
  - subtasks
"""

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    text,
)
from sqlalchemy.orm import DeclarativeBase, relationship, validates
from sqlalchemy.sql import func

from .constants import BUG_CATEGORIES, BUG_PRIORITIES, BUG_SEVERITIES, BUG_STATUSES


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# Read-only stubs
# ---------------------------------------------------------------------------


class User(Base):
    """Read-only stub — maps to worky's users table."""

    __tablename__ = "users"

    id = Column(String(20), primary_key=True)
    email = Column(String(255))
    full_name = Column(String(255))
    role = Column(String(50))
    is_active = Column(Boolean)


class Client(Base):
    """Read-only stub — maps to worky's clients table."""

    __tablename__ = "clients"

    id = Column(String(20), primary_key=True)
    name = Column(String(255))
    is_deleted = Column(Boolean)


class Program(Base):
    """Read-only stub — maps to worky's programs table."""

    __tablename__ = "programs"

    id = Column(String(20), primary_key=True)
    name = Column(String(255))
    is_deleted = Column(Boolean)


class Project(Base):
    """Read-only stub — maps to worky's projects table."""

    __tablename__ = "projects"

    id = Column(String(20), primary_key=True)
    name = Column(String(255))
    program_id = Column(String(20), ForeignKey("programs.id"))
    is_deleted = Column(Boolean)


class Usecase(Base):
    """Read-only stub — maps to worky's usecases table."""

    __tablename__ = "usecases"

    id = Column(String(20), primary_key=True)
    name = Column(String(255))
    project_id = Column(String(20), ForeignKey("projects.id"))
    is_deleted = Column(Boolean)


class UserStory(Base):
    """Read-only stub — maps to worky's user_stories table."""

    __tablename__ = "user_stories"

    id = Column(String(20), primary_key=True)
    name = Column(String(255))
    usecase_id = Column(String(20), ForeignKey("usecases.id"))
    is_deleted = Column(Boolean)


class Task(Base):
    """Read-only stub — maps to worky's tasks table."""

    __tablename__ = "tasks"

    id = Column(String(20), primary_key=True)
    name = Column(String(255))
    user_story_id = Column(String(20), ForeignKey("user_stories.id"))
    is_deleted = Column(Boolean)


class Subtask(Base):
    """Read-only stub — maps to worky's subtasks table."""

    __tablename__ = "subtasks"

    id = Column(String(20), primary_key=True)
    name = Column(String(255))
    task_id = Column(String(20), ForeignKey("tasks.id"))
    is_deleted = Column(Boolean)


class TestRun(Base):
    """Read-only stub — maps to worky's test_runs table."""

    __tablename__ = "test_runs"

    id = Column(String(20), primary_key=True)
    name = Column(String(255))
    is_deleted = Column(Boolean)


class TestCase(Base):
    """Read-only stub — maps to worky's test_cases table."""

    __tablename__ = "test_cases"

    id = Column(String(20), primary_key=True)
    test_case_name = Column(String(255))
    is_deleted = Column(Boolean)


# ---------------------------------------------------------------------------
# Writable models
# ---------------------------------------------------------------------------


class Bug(Base):
    """
    Maps to the existing ``bugs`` table in the worky database.

    This package owns the bug lifecycle — status transitions, assignments,
    resolution tracking. Any additive column extensions are managed via
    the migrations/ folder and must be safely reversible.
    """

    __tablename__ = "bugs"

    # Primary key — relies on worky's generate_string_id DB function on Postgres.
    # For SQLite-based tests, the default is set in conftest.py to avoid
    # overriding Postgres's server_default.
    id = Column(
        String(20),
        primary_key=True,
        server_default=text("generate_string_id('BUG', 'bugs_id_seq')"),
    )

    # Entity type and ID (required for bug linking in worky)
    entity_type = Column(String(50), nullable=False, default="Task")
    entity_id = Column(String(20), nullable=False)

    # QA origin links
    test_run_id = Column(String(20), ForeignKey("test_runs.id"))
    test_case_id = Column(String(20), ForeignKey("test_cases.id"))

    # Hierarchy (nullable — only one typically set)
    client_id = Column(String(20), ForeignKey("clients.id"))
    program_id = Column(String(20), ForeignKey("programs.id"))
    project_id = Column(String(20), ForeignKey("projects.id"))
    usecase_id = Column(String(20), ForeignKey("usecases.id"))
    user_story_id = Column(String(20), ForeignKey("user_stories.id"))
    task_id = Column(String(20), ForeignKey("tasks.id"))
    subtask_id = Column(String(20), ForeignKey("subtasks.id"))

    # Core fields
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)

    # Classification
    category = Column(String(50))
    severity = Column(String(50), nullable=False, default="Medium")
    priority = Column(String(50), nullable=False, default="P2")
    status = Column(String(50), default="New")

    # Assignments
    reporter_id = Column(String(20), ForeignKey("users.id"))
    assignee_id = Column(String(20), ForeignKey("users.id"))
    qa_owner_id = Column(String(20), ForeignKey("users.id"))

    # Reproduction
    reproduction_steps = Column(Text)
    expected_result = Column(Text)
    actual_result = Column(Text)

    # Linked items
    linked_task_id = Column(String(20))
    linked_commit = Column(String(255))
    linked_pr = Column(String(255))

    # Additional
    component_attached_to = Column(String(255))
    environment = Column(String(255))
    reopen_count = Column(Integer, default=0)
    resolution_notes = Column(Text)

    # Legacy fields — kept for backward compatibility with worky
    reported_by = Column(String(20), ForeignKey("users.id"))
    assigned_to = Column(String(20), ForeignKey("users.id"))
    bug_type = Column(String(50))
    resolution_type = Column(String(50))
    found_in_version = Column(String(50))
    fixed_in_version = Column(String(50))
    browser = Column(String(50))
    os = Column(String(50))
    device_type = Column(String(50))
    steps_to_reproduce = Column(Text)
    expected_behavior = Column(Text)
    actual_behavior = Column(Text)

    # Audit
    is_deleted = Column(Boolean, default=False, nullable=False)
    created_by = Column(String(255))
    updated_by = Column(String(255))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    closed_at = Column(DateTime(timezone=True))

    # Relationships (read-only stubs)
    test_run = relationship("TestRun", foreign_keys=[test_run_id])
    test_case = relationship("TestCase", foreign_keys=[test_case_id])
    client = relationship("Client", foreign_keys=[client_id])
    program = relationship("Program", foreign_keys=[program_id])
    project = relationship("Project", foreign_keys=[project_id])
    usecase = relationship("Usecase", foreign_keys=[usecase_id])
    user_story = relationship("UserStory", foreign_keys=[user_story_id])
    task = relationship("Task", foreign_keys=[task_id])
    subtask = relationship("Subtask", foreign_keys=[subtask_id])
    reporter = relationship("User", foreign_keys=[reporter_id])
    assignee = relationship("User", foreign_keys=[assignee_id])
    qa_owner = relationship("User", foreign_keys=[qa_owner_id])
    legacy_reporter = relationship("User", foreign_keys=[reported_by])
    legacy_assignee = relationship("User", foreign_keys=[assigned_to])

    # -----------------------------------------------------------------------
    # Validators
    # -----------------------------------------------------------------------

    @validates("category")
    def validate_category(self, key: str, value: str) -> str:
        if value is None:
            return value
        if value not in BUG_CATEGORIES:
            raise ValueError(f"category must be one of {BUG_CATEGORIES}")
        return value

    @validates("severity")
    def validate_severity(self, key: str, value: str) -> str:
        if value is None:
            return value
        if value not in BUG_SEVERITIES:
            raise ValueError(f"severity must be one of {BUG_SEVERITIES}")
        return value

    @validates("priority")
    def validate_priority(self, key: str, value: str) -> str:
        if value is None:
            return value
        if value not in BUG_PRIORITIES:
            raise ValueError(f"priority must be one of {BUG_PRIORITIES}")
        return value

    @validates("status")
    def validate_status(self, key: str, value: str) -> str:
        if value not in BUG_STATUSES:
            raise ValueError(f"status must be one of {BUG_STATUSES}")
        return value

    def __repr__(self) -> str:
        return f"<Bug id={self.id!r} title={self.title!r} status={self.status!r}>"


class BugComment(Base):
    """
    Maps to the existing ``bug_comments`` table in the worky database.
    
    Comments on bugs with @mentions, edit tracking, and attachments.
    """

    __tablename__ = "bug_comments"

    id = Column(
        String(20),
        primary_key=True,
        server_default=text("generate_string_id('CMT', 'bug_comments_id_seq')"),
    )

    bug_id = Column(String(20), ForeignKey("bugs.id"), nullable=False)

    # Comment content
    comment_text = Column(Text, nullable=False)
    author_id = Column(String(20), ForeignKey("users.id"), nullable=False)

    # Mentions - JSON array of user IDs
    mentioned_users = Column(Text)  # JSON array

    # Attachments - JSON array of file references
    attachments = Column(Text)  # JSON array

    # Edit tracking
    is_edited = Column(Boolean, default=False, nullable=False)
    edited_at = Column(DateTime(timezone=True))

    # Audit
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    is_deleted = Column(Boolean, default=False, nullable=False)

    # Relationships
    bug = relationship("Bug", foreign_keys=[bug_id])
    author = relationship("User", foreign_keys=[author_id])

    def __repr__(self) -> str:
        return f"<BugComment id={self.id!r} bug_id={self.bug_id!r}>"


class BugAttachment(Base):
    """
    Maps to the existing ``bug_attachments`` table in the worky database.
    
    File attachments for bugs - screenshots, logs, etc.
    """

    __tablename__ = "bug_attachments"

    id = Column(
        String(20),
        primary_key=True,
        server_default=text("generate_string_id('ATT', 'bug_attachments_id_seq')"),
    )

    bug_id = Column(String(20), ForeignKey("bugs.id"), nullable=False)

    # File details
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_type = Column(String(50))  # MIME type
    file_size = Column(Integer)  # bytes

    # Audit
    uploaded_by = Column(String(20), ForeignKey("users.id"), nullable=False)
    uploaded_at = Column(DateTime(timezone=True), server_default=func.now())
    is_deleted = Column(Boolean, default=False, nullable=False)

    # Relationships
    bug = relationship("Bug", foreign_keys=[bug_id])
    uploader = relationship("User", foreign_keys=[uploaded_by])

    def __repr__(self) -> str:
        return f"<BugAttachment id={self.id!r} file_name={self.file_name!r}>"


class BugStatusHistory(Base):
    """
    Maps to the existing ``bug_status_history`` table in the worky database.
    
    Tracks all status changes for audit trail and metrics.
    """

    __tablename__ = "bug_status_history"

    id = Column(
        String(20),
        primary_key=True,
        server_default=text("generate_string_id('HST', 'bug_status_history_id_seq')"),
    )

    bug_id = Column(String(20), ForeignKey("bugs.id"), nullable=False)

    # Status transition
    from_status = Column(String(50))  # can be null for initial creation
    to_status = Column(String(50), nullable=False)
    resolution_notes = Column(Text)

    # Audit
    changed_by = Column(String(20), ForeignKey("users.id"), nullable=False)
    changed_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    bug = relationship("Bug", foreign_keys=[bug_id])
    changer = relationship("User", foreign_keys=[changed_by])

    @validates("from_status", "to_status")
    def validate_status(self, key: str, value: str) -> str:
        if value is not None and value not in BUG_STATUSES:
            raise ValueError(f"{key} must be one of {BUG_STATUSES}")
        return value

    def __repr__(self) -> str:
        return f"<BugStatusHistory id={self.id!r} {self.from_status}->{self.to_status}>"
