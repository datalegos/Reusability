"""
Test fixtures for bug-lifecycle-engine.
Uses in-memory SQLite so tests run without a live Postgres instance.

Note: SQLite does not have the generate_string_id() DB function that Postgres uses
for Bug.id's server_default. We use an event listener to generate IDs at insert time
for SQLite.
"""

import uuid
import pytest
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker

from bug_lifecycle_engine.models import Base, Bug, User, Project, TestRun, TestCase, BugComment, BugAttachment, BugStatusHistory


@pytest.fixture(scope="session")
def engine():
    eng = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        future=True,
    )

    @event.listens_for(eng, "connect")
    def set_sqlite_pragma(dbapi_connection, _):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    # Only strip Postgres-specific server_defaults (generate_string_id(...)) that SQLite
    # can't parse in DDL. Leave dialect-agnostic defaults (e.g. func.now()) untouched —
    # those compile correctly on SQLite and are relied on by NOT NULL columns.
    original_server_defaults = {}
    for table in Base.metadata.tables.values():
        for column in table.columns:
            default = column.server_default
            if default is not None and "generate_string_id" in str(default.arg):
                original_server_defaults[column] = default
                column.server_default = None

    Base.metadata.create_all(eng)

    # Restore server_default afterward so production model metadata is unaffected
    # (e.g. if other code inspects Base.metadata for documentation/introspection).
    for column, default in original_server_defaults.items():
        column.server_default = default

    # Set up event listener to generate IDs for SQLite since it lacks generate_string_id()
    @event.listens_for(Bug, "before_insert", propagate=True)
    def receive_before_insert_bug(mapper, connection, target):
        if target.id is None:
            target.id = f"BUG-{str(uuid.uuid4())[:14].upper()}"

    @event.listens_for(BugComment, "before_insert", propagate=True)
    def receive_before_insert_comment(mapper, connection, target):
        if target.id is None:
            target.id = f"CMT-{str(uuid.uuid4())[:14].upper()}"

    @event.listens_for(BugAttachment, "before_insert", propagate=True)
    def receive_before_insert_attachment(mapper, connection, target):
        if target.id is None:
            target.id = f"ATT-{str(uuid.uuid4())[:14].upper()}"

    @event.listens_for(BugStatusHistory, "before_insert", propagate=True)
    def receive_before_insert_history(mapper, connection, target):
        if target.id is None:
            target.id = f"HST-{str(uuid.uuid4())[:14].upper()}"

    yield eng
    Base.metadata.drop_all(eng)


@pytest.fixture()
def session(engine):
    """Transactional test session — rolls back after each test."""
    connection = engine.connect()
    transaction = connection.begin()
    Session = sessionmaker(bind=connection, autocommit=False, autoflush=False)
    sess = Session()
    yield sess
    sess.close()
    transaction.rollback()
    connection.close()


# ---------------------------------------------------------------------------
# Seed helpers
# ---------------------------------------------------------------------------

def seed_user(session, user_id: str = "USR-000001") -> User:
    u = User(id=user_id, email="qa@example.com", full_name="QA Bot", is_active=True)
    session.add(u)
    session.flush()
    return u


def seed_project(session, project_id: str = "PRJ-000001") -> Project:
    p = Project(id=project_id, name="Alpha", is_deleted=False)
    session.add(p)
    session.flush()
    return p


def seed_hierarchy(session):
    """Create a complete hierarchy for testing."""
    # Ensure we have a project to link to
    project = seed_project(session, "PRJ-000001")
    return project


def seed_test_run(session, run_id: str = "RUN-000001") -> TestRun:
    r = TestRun(id=run_id, name="Regression", is_deleted=False)
    session.add(r)
    session.flush()
    return r


def seed_bug(session, bug_id: str = None, **overrides) -> Bug:
    """Create a bug with default values, allowing field overrides."""
    from bug_lifecycle_engine.schemas import BugCreate
    from bug_lifecycle_engine.crud import BugCRUD
    
    defaults = {
        "title": "Test bug",
        "description": "Test description",
        "status": "New",
        "created_by": "USR-000001"
    }
    defaults.update(overrides)
    
    crud = BugCRUD(session)
    bug = crud.create(BugCreate(**defaults))
    return bug
