"""
Tests for bug lifecycle constants — ensures the transition graph is internally consistent.
"""

from bug_lifecycle_engine.constants import BUG_STATUS_TRANSITIONS, BUG_STATUSES


class TestTransitionGraph:
    def test_all_statuses_have_transitions(self):
        """Every status must appear as a key in the transition map."""
        for status in BUG_STATUSES:
            assert status in BUG_STATUS_TRANSITIONS, (
                f"Status '{status}' has no entry in BUG_STATUS_TRANSITIONS"
            )

    def test_all_transition_targets_are_valid_statuses(self):
        """Every value in the transition map must be a known status."""
        valid = set(BUG_STATUSES)
        for src, targets in BUG_STATUS_TRANSITIONS.items():
            for tgt in targets:
                assert tgt in valid, (
                    f"Transition target '{tgt}' (from '{src}') is not a valid status"
                )

    def test_closed_can_be_reopened(self):
        assert "Reopened" in BUG_STATUS_TRANSITIONS["Closed"]

    def test_new_cannot_go_to_verified(self):
        assert "Verified" not in BUG_STATUS_TRANSITIONS["New"]

    def test_reopened_leads_back_to_active(self):
        targets = BUG_STATUS_TRANSITIONS["Reopened"]
        assert any(t in ("Open", "In Progress") for t in targets)
