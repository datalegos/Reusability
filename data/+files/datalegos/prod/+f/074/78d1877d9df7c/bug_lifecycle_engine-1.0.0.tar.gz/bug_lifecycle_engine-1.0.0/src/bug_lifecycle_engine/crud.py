"""
CRUD operations for the bugs table.

Key rules enforced here:
- Status transitions follow BUG_STATUS_TRANSITIONS — invalid moves raise ValueError.
- Reopen increments reopen_count.
- Closing a bug sets closed_at.
- All writes are additive — no column is dropped or type-changed here.
- Hierarchy tables are read-only FK targets only.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional

from sqlalchemy import select, func, or_
from sqlalchemy.orm import Session

from .constants import BUG_STATUS_TRANSITIONS
from .models import (
    Bug, BugComment, BugAttachment, BugStatusHistory, 
    Project, Usecase, UserStory, Task, Subtask
)
from .schemas import BugCreate, BugStatusTransition, BugUpdate


class BugCRUD:
    """
    Full lifecycle CRUD for Bug.

    Usage::

        with get_session(engine) as session:
            crud = BugCRUD(session)
            bug = crud.create(payload)
            crud.transition(bug.id, BugStatusTransition(new_status="Open", updated_by="USR-1"))
    """

    def __init__(self, session: Session) -> None:
        self._session = session

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get(self, bug_id: str) -> Optional[Bug]:
        """Fetch a bug by primary key. Returns None if not found."""
        return self._session.get(Bug, bug_id)

    def get_or_raise(self, bug_id: str) -> Bug:
        """Fetch a bug or raise ValueError if not found or soft-deleted."""
        bug = self.get(bug_id)
        if bug is None or bug.is_deleted:
            raise ValueError(f"Bug '{bug_id}' not found")
        return bug

    def list_all(
        self,
        skip: int = 0,
        limit: int = 50,
        include_deleted: bool = False,
    ) -> List[Bug]:
        stmt = select(Bug)
        if not include_deleted:
            stmt = stmt.where(Bug.is_deleted.is_(False))
        stmt = stmt.offset(skip).limit(limit).order_by(Bug.created_at.desc())
        return list(self._session.scalars(stmt))

    def list_by_project(
        self,
        project_id: str,
        skip: int = 0,
        limit: int = 50,
        include_deleted: bool = False,
    ) -> List[Bug]:
        stmt = select(Bug).where(Bug.project_id == project_id)
        if not include_deleted:
            stmt = stmt.where(Bug.is_deleted.is_(False))
        stmt = stmt.offset(skip).limit(limit).order_by(Bug.created_at.desc())
        return list(self._session.scalars(stmt))

    def list_by_status(
        self,
        status: str,
        skip: int = 0,
        limit: int = 50,
    ) -> List[Bug]:
        stmt = (
            select(Bug)
            .where(Bug.status == status, Bug.is_deleted.is_(False))
            .offset(skip)
            .limit(limit)
            .order_by(Bug.created_at.desc())
        )
        return list(self._session.scalars(stmt))

    def list_by_assignee(
        self,
        assignee_id: str,
        skip: int = 0,
        limit: int = 50,
    ) -> List[Bug]:
        stmt = (
            select(Bug)
            .where(Bug.assignee_id == assignee_id, Bug.is_deleted.is_(False))
            .offset(skip)
            .limit(limit)
            .order_by(Bug.created_at.desc())
        )
        return list(self._session.scalars(stmt))

    def list_by_test_run(
        self,
        test_run_id: str,
        skip: int = 0,
        limit: int = 50,
    ) -> List[Bug]:
        stmt = (
            select(Bug)
            .where(Bug.test_run_id == test_run_id, Bug.is_deleted.is_(False))
            .offset(skip)
            .limit(limit)
            .order_by(Bug.created_at.desc())
        )
        return list(self._session.scalars(stmt))

    def _get_descendant_ids(
        self,
        project_id: Optional[str] = None,
        usecase_id: Optional[str] = None,
        user_story_id: Optional[str] = None,
        task_id: Optional[str] = None,
        subtask_id: Optional[str] = None,
    ) -> dict:
        """
        Get all descendant IDs for the given hierarchy level.
        
        Returns a dict with keys for each hierarchy level containing the set of IDs
        that should be included in the descendant filtering.
        """
        result = {
            "project_ids": set(),
            "usecase_ids": set(), 
            "user_story_ids": set(),
            "task_ids": set(),
            "subtask_ids": set(),
        }
        
        # If subtask_id is specified, only include that specific subtask
        if subtask_id:
            result["subtask_ids"] = {subtask_id}
            return result
            
        # If task_id is specified, include the task and all its subtasks
        if task_id:
            result["task_ids"] = {task_id}
            # Get all subtasks under this task
            subtask_stmt = select(Subtask.id).where(
                Subtask.task_id == task_id,
                Subtask.is_deleted.is_(False)
            )
            subtask_rows = self._session.execute(subtask_stmt).all()
            result["subtask_ids"] = {row.id for row in subtask_rows}
            return result
            
        # If user_story_id is specified, include the user story and all its tasks/subtasks
        if user_story_id:
            result["user_story_ids"] = {user_story_id}
            # Get all tasks under this user story
            task_stmt = select(Task.id).where(
                Task.user_story_id == user_story_id,
                Task.is_deleted.is_(False)
            )
            task_rows = self._session.execute(task_stmt).all()
            result["task_ids"] = {row.id for row in task_rows}
            
            # Get all subtasks under these tasks
            if result["task_ids"]:
                subtask_stmt = select(Subtask.id).where(
                    Subtask.task_id.in_(result["task_ids"]),
                    Subtask.is_deleted.is_(False)
                )
                subtask_rows = self._session.execute(subtask_stmt).all()
                result["subtask_ids"] = {row.id for row in subtask_rows}
            return result
            
        # If usecase_id is specified, include the usecase and all its user stories/tasks/subtasks
        if usecase_id:
            result["usecase_ids"] = {usecase_id}
            # Get all user stories under this usecase
            user_story_stmt = select(UserStory.id).where(
                UserStory.usecase_id == usecase_id,
                UserStory.is_deleted.is_(False)
            )
            user_story_rows = self._session.execute(user_story_stmt).all()
            result["user_story_ids"] = {row.id for row in user_story_rows}
            
            # Get all tasks under these user stories
            if result["user_story_ids"]:
                task_stmt = select(Task.id).where(
                    Task.user_story_id.in_(result["user_story_ids"]),
                    Task.is_deleted.is_(False)
                )
                task_rows = self._session.execute(task_stmt).all()
                result["task_ids"] = {row.id for row in task_rows}
                
                # Get all subtasks under these tasks
                if result["task_ids"]:
                    subtask_stmt = select(Subtask.id).where(
                        Subtask.task_id.in_(result["task_ids"]),
                        Subtask.is_deleted.is_(False)
                    )
                    subtask_rows = self._session.execute(subtask_stmt).all()
                    result["subtask_ids"] = {row.id for row in subtask_rows}
            return result
            
        # If project_id is specified, include the project and all its usecases/user stories/tasks/subtasks
        if project_id:
            result["project_ids"] = {project_id}
            # Get all usecases under this project
            usecase_stmt = select(Usecase.id).where(
                Usecase.project_id == project_id,
                Usecase.is_deleted.is_(False)
            )
            usecase_rows = self._session.execute(usecase_stmt).all()
            result["usecase_ids"] = {row.id for row in usecase_rows}
            
            # Get all user stories under these usecases
            if result["usecase_ids"]:
                user_story_stmt = select(UserStory.id).where(
                    UserStory.usecase_id.in_(result["usecase_ids"]),
                    UserStory.is_deleted.is_(False)
                )
                user_story_rows = self._session.execute(user_story_stmt).all()
                result["user_story_ids"] = {row.id for row in user_story_rows}
                
                # Get all tasks under these user stories
                if result["user_story_ids"]:
                    task_stmt = select(Task.id).where(
                        Task.user_story_id.in_(result["user_story_ids"]),
                        Task.is_deleted.is_(False)
                    )
                    task_rows = self._session.execute(task_stmt).all()
                    result["task_ids"] = {row.id for row in task_rows}
                    
                    # Get all subtasks under these tasks
                    if result["task_ids"]:
                        subtask_stmt = select(Subtask.id).where(
                            Subtask.task_id.in_(result["task_ids"]),
                            Subtask.is_deleted.is_(False)
                        )
                        subtask_rows = self._session.execute(subtask_stmt).all()
                        result["subtask_ids"] = {row.id for row in subtask_rows}
            return result
            
        return result

    def list_by_hierarchy(
        self,
        project_id: Optional[str] = None,
        usecase_id: Optional[str] = None,
        user_story_id: Optional[str] = None,
        task_id: Optional[str] = None,
        subtask_id: Optional[str] = None,
        include_descendants: bool = True,
        status: Optional[List[str]] = None,
        severity: Optional[List[str]] = None,
        priority: Optional[List[str]] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> List[Bug]:
        """
        List bugs by hierarchy level with optional filters.
        
        This implements the main filtering logic for the GET /bugs/hierarchy endpoint.
        
        When include_descendants=True, includes bugs from all descendant hierarchy levels.
        For example, if project_id is set, includes bugs from all usecases, user stories, 
        tasks, and subtasks under that project.
        
        When include_descendants=False, only returns bugs exactly matching the specified
        hierarchy level.
        """
        stmt = select(Bug).where(Bug.is_deleted.is_(False))
        
        # Apply hierarchy filters
        if include_descendants:
            # Get all descendant IDs and filter by them
            descendant_ids = self._get_descendant_ids(
                project_id=project_id,
                usecase_id=usecase_id, 
                user_story_id=user_story_id,
                task_id=task_id,
                subtask_id=subtask_id
            )
            
            # Build OR conditions for all hierarchy levels that have descendants
            or_conditions = []
            
            # Add exact match for the specified level
            if subtask_id:
                or_conditions.append(Bug.subtask_id == subtask_id)
            elif task_id:
                or_conditions.append(Bug.task_id == task_id)
            elif user_story_id:
                or_conditions.append(Bug.user_story_id == user_story_id)
            elif usecase_id:
                or_conditions.append(Bug.usecase_id == usecase_id)
            elif project_id:
                or_conditions.append(Bug.project_id == project_id)
            
            # Add descendant conditions
            if descendant_ids["subtask_ids"]:
                or_conditions.append(Bug.subtask_id.in_(descendant_ids["subtask_ids"]))
            if descendant_ids["task_ids"]:
                or_conditions.append(Bug.task_id.in_(descendant_ids["task_ids"]))
            if descendant_ids["user_story_ids"]:
                or_conditions.append(Bug.user_story_id.in_(descendant_ids["user_story_ids"]))
            if descendant_ids["usecase_ids"]:
                or_conditions.append(Bug.usecase_id.in_(descendant_ids["usecase_ids"]))
            if descendant_ids["project_ids"]:
                or_conditions.append(Bug.project_id.in_(descendant_ids["project_ids"]))
            
            if or_conditions:
                stmt = stmt.where(or_(*or_conditions))
        else:
            # Exact match filtering only - original behavior
            if subtask_id:
                stmt = stmt.where(Bug.subtask_id == subtask_id)
            elif task_id:
                stmt = stmt.where(Bug.task_id == task_id)
            elif user_story_id:
                stmt = stmt.where(Bug.user_story_id == user_story_id)
            elif usecase_id:
                stmt = stmt.where(Bug.usecase_id == usecase_id)
            elif project_id:
                stmt = stmt.where(Bug.project_id == project_id)
        
        # Apply status filters
        if status:
            stmt = stmt.where(Bug.status.in_(status))
            
        # Apply severity filters  
        if severity:
            stmt = stmt.where(Bug.severity.in_(severity))
            
        # Apply priority filters
        if priority:
            stmt = stmt.where(Bug.priority.in_(priority))
            
        # Apply pagination and ordering
        stmt = stmt.offset(skip).limit(limit).order_by(Bug.created_at.desc())
        
        return list(self._session.scalars(stmt))

    def count_by_status(self, project_id: Optional[str] = None) -> dict:
        """
        Return a {status: count} breakdown.
        Optionally scoped to a project.
        """
        stmt = (
            select(Bug.status, func.count().label("cnt"))
            .where(Bug.is_deleted.is_(False))
            .group_by(Bug.status)
        )
        if project_id:
            stmt = stmt.where(Bug.project_id == project_id)
        rows = self._session.execute(stmt).all()
        return {row.status: row.cnt for row in rows}

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def create(self, payload: BugCreate) -> Bug:
        """Create a new bug in 'New' status."""
        data = payload.model_dump()
        
        # Handle legacy field mapping for backward compatibility
        # Set reported_by to reporter_id for database constraint (required field)
        if 'reporter_id' in data and data['reporter_id']:
            data['reported_by'] = data['reporter_id']
        elif data.get('created_by'):
            # Fallback: use created_by for reported_by if reporter_id is not set
            data['reported_by'] = data['created_by']
            data['reporter_id'] = data['created_by']
        
        # Set assigned_to to assignee_id for backward compatibility
        if 'assignee_id' in data and data['assignee_id']:
            data['assigned_to'] = data['assignee_id']
            
        # Auto-derive entity_type and entity_id from hierarchy fields
        if not data.get('entity_id'):
            entity_type = data.get('entity_type', 'Task')
            
            # If entity_type is explicitly provided, try to match it with hierarchy
            if entity_type == 'Task' and data.get('task_id'):
                data['entity_id'] = data['task_id']
            elif entity_type == 'Subtask' and data.get('subtask_id'):
                data['entity_id'] = data['subtask_id']
            elif entity_type == 'UserStory' and data.get('user_story_id'):
                data['entity_id'] = data['user_story_id']
            elif entity_type == 'Usecase' and data.get('usecase_id'):
                data['entity_id'] = data['usecase_id']
            elif entity_type == 'Project' and data.get('project_id'):
                data['entity_id'] = data['project_id']
            elif entity_type == 'Program' and data.get('program_id'):
                data['entity_id'] = data['program_id']
            elif entity_type == 'Client' and data.get('client_id'):
                data['entity_id'] = data['client_id']
            else:
                # Auto-detect entity_type from the highest-level hierarchy field provided
                # This covers the common case where entity_type is "Task" but other hierarchy is set
                if data.get('subtask_id'):
                    data['entity_type'] = 'Subtask'
                    data['entity_id'] = data['subtask_id']
                elif data.get('task_id'):
                    data['entity_type'] = 'Task' 
                    data['entity_id'] = data['task_id']
                elif data.get('user_story_id'):
                    data['entity_type'] = 'UserStory'
                    data['entity_id'] = data['user_story_id']
                elif data.get('usecase_id'):
                    data['entity_type'] = 'Usecase'
                    data['entity_id'] = data['usecase_id']
                elif data.get('project_id'):
                    data['entity_type'] = 'Project'
                    data['entity_id'] = data['project_id']
                elif data.get('program_id'):
                    data['entity_type'] = 'Program'
                    data['entity_id'] = data['program_id']
                elif data.get('client_id'):
                    data['entity_type'] = 'Client'
                    data['entity_id'] = data['client_id']
                else:
                    # If no hierarchy field is provided, create a placeholder entity_id
                    # This ensures the NOT NULL constraint is satisfied while maintaining
                    # compatibility with existing worky integration
                    data['entity_id'] = f"DEFAULT-{entity_type}-ID"
            
        bug = Bug(**data)
        self._session.add(bug)
        self._session.flush()
        return bug

    def update(self, bug_id: str, payload: BugUpdate) -> Bug:
        """
        Apply a partial field update.
        Does NOT allow status changes — use transition() for that.
        """
        bug = self.get_or_raise(bug_id)
        for field, value in payload.model_dump(exclude_unset=True).items():
            setattr(bug, field, value)
        self._session.flush()
        return bug

    def transition(self, bug_id: str, payload: BugStatusTransition) -> Bug:
        """
        Move a bug to a new status, enforcing the allowed transition graph.
        
        Automatically creates a BugStatusHistory record for audit trail.

        Special side-effects:
        - Closing a bug → sets closed_at timestamp.
        - Reopening a bug → increments reopen_count, clears closed_at.
        - 'Fixed' → records fixed_in_version if provided via resolution_notes field.
        """
        bug = self.get_or_raise(bug_id)
        current = bug.status
        new = payload.new_status

        allowed = BUG_STATUS_TRANSITIONS.get(current, ())
        if new not in allowed:
            raise ValueError(
                f"Cannot transition bug from '{current}' to '{new}'. "
                f"Allowed next statuses: {allowed}"
            )

        bug.status = new
        bug.updated_by = payload.updated_by

        if payload.resolution_notes is not None:
            bug.resolution_notes = payload.resolution_notes

        now = datetime.now(timezone.utc)

        if new == "Closed":
            bug.closed_at = now
        elif new == "Reopened":
            bug.reopen_count = (bug.reopen_count or 0) + 1
            bug.closed_at = None

        # Auto-create status history record
        history_crud = BugStatusHistoryCRUD(self._session)
        history_crud._create_history_record(
            bug_id=bug_id,
            from_status=current,
            to_status=new,
            changed_by=payload.updated_by,
            resolution_notes=payload.resolution_notes
        )

        self._session.flush()
        return bug

    def assign(self, bug_id: str, assignee_id: str, updated_by: str) -> Bug:
        """Assign a bug to a developer."""
        bug = self.get_or_raise(bug_id)
        bug.assignee_id = assignee_id
        bug.updated_by = updated_by
        self._session.flush()
        return bug

    def set_qa_owner(self, bug_id: str, qa_owner_id: str, updated_by: str) -> Bug:
        """Set the QA owner for a bug."""
        bug = self.get_or_raise(bug_id)
        bug.qa_owner_id = qa_owner_id
        bug.updated_by = updated_by
        self._session.flush()
        return bug

    def soft_delete(self, bug_id: str, deleted_by: str) -> Bug:
        """Mark a bug as deleted without removing the row."""
        bug = self.get_or_raise(bug_id)
        bug.is_deleted = True
        bug.updated_by = deleted_by
        self._session.flush()
        return bug


class BugCommentCRUD:
    """
    CRUD operations for bug comments.
    
    Usage::
    
        with get_session(engine) as session:
            crud = BugCommentCRUD(session)
            comment = crud.create(CommentCreate(...))
            crud.update(comment.id, CommentUpdate(...), user_id="USR-123")
    """

    def __init__(self, session: Session) -> None:
        self._session = session

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get(self, comment_id: str) -> Optional[BugComment]:
        """Fetch a comment by primary key. Returns None if not found."""
        return self._session.get(BugComment, comment_id)

    def get_or_raise(self, comment_id: str) -> BugComment:
        """Fetch a comment or raise ValueError if not found or soft-deleted."""
        comment = self.get(comment_id)
        if comment is None or comment.is_deleted:
            raise ValueError(f"Comment '{comment_id}' not found")
        return comment

    def list_by_bug(
        self,
        bug_id: str,
        skip: int = 0,
        limit: int = 50,
        include_deleted: bool = False,
    ) -> List[BugComment]:
        """List comments for a specific bug, ordered by creation time."""
        stmt = select(BugComment).where(BugComment.bug_id == bug_id)
        if not include_deleted:
            stmt = stmt.where(BugComment.is_deleted.is_(False))
        stmt = stmt.offset(skip).limit(limit).order_by(BugComment.created_at.asc())
        return list(self._session.scalars(stmt))

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def create(self, bug_id: str, comment_text: str, author_id: str, 
               mentioned_users: Optional[List[str]] = None,
               attachments: Optional[List[str]] = None) -> BugComment:
        """Create a new comment on a bug."""
        comment_data = {
            "bug_id": bug_id,
            "comment_text": comment_text,
            "author_id": author_id,
        }
        
        if mentioned_users:
            import json
            comment_data["mentioned_users"] = json.dumps(mentioned_users)
        
        if attachments:
            import json
            comment_data["attachments"] = json.dumps(attachments)
        
        comment = BugComment(**comment_data)
        self._session.add(comment)
        self._session.flush()
        return comment

    def update(self, comment_id: str, comment_text: str, updated_by: str) -> BugComment:
        """
        Update comment text (only within 15 minutes of creation and by the author).
        """
        comment = self.get_or_raise(comment_id)
        
        # Check if author is making the update
        if comment.author_id != updated_by:
            raise ValueError("Only the comment author can edit their comment")
        
        # Check 15-minute edit window
        now = datetime.now(timezone.utc)
        time_since_creation = now - comment.created_at.replace(tzinfo=timezone.utc)
        if time_since_creation.total_seconds() > 900:  # 15 minutes
            raise ValueError("Comments can only be edited within 15 minutes of posting")
        
        comment.comment_text = comment_text
        comment.is_edited = True
        comment.edited_at = now
        self._session.flush()
        return comment

    def delete(self, comment_id: str, deleted_by: str) -> BugComment:
        """Soft delete a comment (only by the author)."""
        comment = self.get_or_raise(comment_id)
        
        # Check if author is making the deletion
        if comment.author_id != deleted_by:
            raise ValueError("Only the comment author can delete their comment")
        
        comment.is_deleted = True
        self._session.flush()
        return comment


class BugAttachmentCRUD:
    """
    CRUD operations for bug attachments.
    
    Usage::
    
        with get_session(engine) as session:
            crud = BugAttachmentCRUD(session)
            attachment = crud.create(AttachmentCreate(...))
    """

    def __init__(self, session: Session) -> None:
        self._session = session

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get(self, attachment_id: str) -> Optional[BugAttachment]:
        """Fetch an attachment by primary key. Returns None if not found."""
        return self._session.get(BugAttachment, attachment_id)

    def get_or_raise(self, attachment_id: str) -> BugAttachment:
        """Fetch an attachment or raise ValueError if not found or soft-deleted."""
        attachment = self.get(attachment_id)
        if attachment is None or attachment.is_deleted:
            raise ValueError(f"Attachment '{attachment_id}' not found")
        return attachment

    def list_by_bug(
        self,
        bug_id: str,
        skip: int = 0,
        limit: int = 50,
        include_deleted: bool = False,
    ) -> List[BugAttachment]:
        """List attachments for a specific bug, ordered by upload time."""
        stmt = select(BugAttachment).where(BugAttachment.bug_id == bug_id)
        if not include_deleted:
            stmt = stmt.where(BugAttachment.is_deleted.is_(False))
        stmt = stmt.offset(skip).limit(limit).order_by(BugAttachment.uploaded_at.desc())
        return list(self._session.scalars(stmt))

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def create(self, bug_id: str, file_name: str, file_path: str, 
               uploaded_by: str, file_type: Optional[str] = None,
               file_size: Optional[int] = None) -> BugAttachment:
        """Create a new attachment for a bug."""
        attachment = BugAttachment(
            bug_id=bug_id,
            file_name=file_name,
            file_path=file_path,
            file_type=file_type,
            file_size=file_size,
            uploaded_by=uploaded_by,
        )
        self._session.add(attachment)
        self._session.flush()
        return attachment

    def soft_delete(self, attachment_id: str, deleted_by: str) -> BugAttachment:
        """Mark an attachment as deleted without removing the row."""
        attachment = self.get_or_raise(attachment_id)
        attachment.is_deleted = True
        self._session.flush()
        return attachment


class BugStatusHistoryCRUD:
    """
    Read-only CRUD for bug status history.
    
    Status history records are created automatically by BugCRUD.transition(),
    not directly via this class.
    
    Usage::
    
        with get_session(engine) as session:
            crud = BugStatusHistoryCRUD(session)
            history = crud.list_by_bug("BUG-123")
    """

    def __init__(self, session: Session) -> None:
        self._session = session

    # ------------------------------------------------------------------
    # Read (no write methods - history is managed by BugCRUD.transition)
    # ------------------------------------------------------------------

    def get(self, history_id: str) -> Optional[BugStatusHistory]:
        """Fetch a status history record by primary key."""
        return self._session.get(BugStatusHistory, history_id)

    def list_by_bug(
        self,
        bug_id: str,
        skip: int = 0,
        limit: int = 50,
    ) -> List[BugStatusHistory]:
        """List status history for a specific bug, ordered by change time (newest first)."""
        stmt = (
            select(BugStatusHistory)
            .where(BugStatusHistory.bug_id == bug_id)
            .offset(skip)
            .limit(limit)
            .order_by(BugStatusHistory.changed_at.desc())
        )
        return list(self._session.scalars(stmt))

    def _create_history_record(self, bug_id: str, from_status: Optional[str], 
                              to_status: str, changed_by: str, 
                              resolution_notes: Optional[str] = None) -> BugStatusHistory:
        """
        Internal method to create status history record.
        Called by BugCRUD.transition() - not for external use.
        """
        history = BugStatusHistory(
            bug_id=bug_id,
            from_status=from_status,
            to_status=to_status,
            resolution_notes=resolution_notes,
            changed_by=changed_by,
        )
        self._session.add(history)
        self._session.flush()
        return history
