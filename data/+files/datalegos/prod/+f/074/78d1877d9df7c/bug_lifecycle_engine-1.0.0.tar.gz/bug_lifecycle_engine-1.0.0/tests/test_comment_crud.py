"""
Tests for BugCommentCRUD operations.
"""

import json
import pytest
from datetime import datetime, timezone, timedelta

from bug_lifecycle_engine.crud import BugCommentCRUD
from bug_lifecycle_engine.models import BugComment
from tests.conftest import seed_user, seed_bug


class TestBugCommentCRUD:
    """Test comment CRUD operations."""

    def test_create_minimal_comment(self, session):
        """Test creating a basic comment."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugCommentCRUD(session)
        comment = crud.create(
            bug_id=bug.id,
            comment_text="This is a test comment",
            author_id="USR-000001"
        )
        
        assert comment.id is not None
        assert comment.bug_id == bug.id
        assert comment.comment_text == "This is a test comment"
        assert comment.author_id == "USR-000001"
        assert comment.is_edited is False
        assert comment.edited_at is None
        assert comment.mentioned_users is None
        assert comment.attachments is None
        assert comment.is_deleted is False

    def test_create_comment_with_mentions_and_attachments(self, session):
        """Test creating a comment with mentions and attachments."""
        seed_user(session)
        seed_user(session, "USR-000002")
        bug = seed_bug(session)
        
        crud = BugCommentCRUD(session)
        comment = crud.create(
            bug_id=bug.id,
            comment_text="Hey @john, check this attachment!",
            author_id="USR-000001",
            mentioned_users=["USR-000002"],
            attachments=["screenshot.png", "error.log"]
        )
        
        assert comment.mentioned_users is not None
        # Parse JSON to verify content
        mentions = json.loads(comment.mentioned_users)
        assert mentions == ["USR-000002"]
        
        attachments = json.loads(comment.attachments)
        assert attachments == ["screenshot.png", "error.log"]

    def test_list_comments_by_bug(self, session):
        """Test listing comments for a specific bug."""
        seed_user(session)
        bug1 = seed_bug(session)
        bug2 = seed_bug(session)
        
        crud = BugCommentCRUD(session)
        
        # Create comments for both bugs
        comment1 = crud.create(bug1.id, "Comment on bug 1", "USR-000001")
        comment2 = crud.create(bug1.id, "Another comment on bug 1", "USR-000001")
        comment3 = crud.create(bug2.id, "Comment on bug 2", "USR-000001")
        
        # List comments for bug1
        bug1_comments = crud.list_by_bug(bug1.id)
        assert len(bug1_comments) == 2
        comment_ids = [c.id for c in bug1_comments]
        assert comment1.id in comment_ids
        assert comment2.id in comment_ids
        assert comment3.id not in comment_ids

    def test_update_comment_within_time_limit(self, session):
        """Test updating a comment within the 15-minute window."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugCommentCRUD(session)
        comment = crud.create(bug.id, "Original text", "USR-000001")
        
        # Update immediately (should work)
        updated = crud.update(comment.id, "Updated text", "USR-000001")
        
        assert updated.comment_text == "Updated text"
        assert updated.is_edited is True
        assert updated.edited_at is not None

    def test_update_comment_by_different_user_fails(self, session):
        """Test that only the author can update their comment."""
        seed_user(session)
        seed_user(session, "USR-000002")
        bug = seed_bug(session)
        
        crud = BugCommentCRUD(session)
        comment = crud.create(bug.id, "Original text", "USR-000001")
        
        # Try to update by different user
        with pytest.raises(ValueError, match="Only the comment author"):
            crud.update(comment.id, "Hacked text", "USR-000002")

    def test_update_comment_after_time_limit_fails(self, session):
        """Test that comments cannot be updated after 15 minutes."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugCommentCRUD(session)
        comment = crud.create(bug.id, "Original text", "USR-000001")
        
        # Manually set created_at to 16 minutes ago
        old_time = datetime.now(timezone.utc) - timedelta(minutes=16)
        comment.created_at = old_time
        session.flush()
        
        # Try to update after time limit
        with pytest.raises(ValueError, match="Comments can only be edited within 15 minutes"):
            crud.update(comment.id, "Too late text", "USR-000001")

    def test_delete_comment_by_author(self, session):
        """Test deleting a comment by its author."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugCommentCRUD(session)
        comment = crud.create(bug.id, "To be deleted", "USR-000001")
        
        # Delete by author
        deleted = crud.delete(comment.id, "USR-000001")
        
        assert deleted.is_deleted is True
        
        # Verify it doesn't appear in list_by_bug
        comments = crud.list_by_bug(bug.id, include_deleted=False)
        assert len(comments) == 0
        
        # But appears when including deleted
        comments_with_deleted = crud.list_by_bug(bug.id, include_deleted=True)
        assert len(comments_with_deleted) == 1

    def test_delete_comment_by_different_user_fails(self, session):
        """Test that only the author can delete their comment."""
        seed_user(session)
        seed_user(session, "USR-000002")
        bug = seed_bug(session)
        
        crud = BugCommentCRUD(session)
        comment = crud.create(bug.id, "Protected comment", "USR-000001")
        
        # Try to delete by different user
        with pytest.raises(ValueError, match="Only the comment author"):
            crud.delete(comment.id, "USR-000002")

    def test_get_nonexistent_comment(self, session):
        """Test getting a non-existent comment."""
        crud = BugCommentCRUD(session)
        assert crud.get("NONEXISTENT") is None
        
        with pytest.raises(ValueError, match="not found"):
            crud.get_or_raise("NONEXISTENT")

    def test_pagination(self, session):
        """Test comment pagination."""
        seed_user(session)
        bug = seed_bug(session)
        
        crud = BugCommentCRUD(session)
        
        # Create 5 comments
        for i in range(5):
            crud.create(bug.id, f"Comment {i}", "USR-000001")
        
        # Test pagination
        page1 = crud.list_by_bug(bug.id, skip=0, limit=3)
        page2 = crud.list_by_bug(bug.id, skip=3, limit=3)
        
        assert len(page1) == 3
        assert len(page2) == 2
        
        # Ensure no overlap
        page1_ids = [c.id for c in page1]
        page2_ids = [c.id for c in page2]
        assert not set(page1_ids).intersection(set(page2_ids))