"""
Tests for hierarchical bug filtering functionality.
"""

import pytest

from bug_lifecycle_engine.crud import BugCRUD
from bug_lifecycle_engine.schemas import BugCreate
from bug_lifecycle_engine.models import Project, Usecase, UserStory, Task, Subtask
from tests.conftest import seed_user, seed_project


def seed_hierarchy(session):
    """Create a test hierarchy: Project -> Usecase -> UserStory -> Task -> Subtask."""
    project = seed_project(session, "PRJ-000001")
    
    # Create usecase under the project
    usecase = Usecase(id="UC-000001", name="Test Usecase", project_id="PRJ-000001", is_deleted=False)
    session.add(usecase)
    session.flush()  # Ensure usecase is created before user story
    
    # Create user story under the usecase
    user_story = UserStory(id="US-000001", name="Test User Story", usecase_id="UC-000001", is_deleted=False)
    session.add(user_story)
    session.flush()  # Ensure user story is created before task
    
    # Create task under the user story
    task = Task(id="TSK-000001", name="Test Task", user_story_id="US-000001", is_deleted=False)
    session.add(task)
    session.flush()  # Ensure task is created before subtask
    
    # Create subtask under the task
    subtask = Subtask(id="SUB-000001", name="Test Subtask", task_id="TSK-000001", is_deleted=False)
    session.add(subtask)
    session.flush()
    
    return project, usecase, user_story, task, subtask


class TestHierarchyFiltering:
    """Test hierarchical bug filtering with list_by_hierarchy."""

    def test_filter_by_project_only(self, session):
        """Test filtering bugs by project ID only."""
        seed_user(session)
        project = seed_hierarchy(session)  # Creates PRJ-000001
        seed_project(session, "PRJ-999999")  # Create second project
        
        crud = BugCRUD(session)
        
        # Create bugs at different projects
        bug1 = crud.create(BugCreate(
            title="Project level bug",
            description="Bug at project level",
            project_id="PRJ-000001",
            created_by="USR-000001"
        ))
        
        bug2 = crud.create(BugCreate(
            title="Different project bug", 
            description="Bug at different project",
            project_id="PRJ-999999",
            created_by="USR-000001"
        ))
        
        # Filter by project
        results = crud.list_by_hierarchy(project_id="PRJ-000001")
        
        bug_ids = [b.id for b in results]
        assert bug1.id in bug_ids
        assert bug2.id not in bug_ids

    def test_filter_with_status_and_severity(self, session):
        """Test filtering with additional status and severity filters."""
        seed_user(session)
        seed_hierarchy(session)  # Creates PRJ-000001
        
        crud = BugCRUD(session)
        
        # Create bugs with different statuses and severities
        bug1 = crud.create(BugCreate(
            title="High severity open bug",
            description="Test bug",
            project_id="PRJ-000001",
            status="Open",
            severity="High",
            created_by="USR-000001"
        ))
        
        bug2 = crud.create(BugCreate(
            title="Low severity new bug",
            description="Test bug",
            project_id="PRJ-000001", 
            status="New",
            severity="Low",
            created_by="USR-000001"
        ))
        
        bug3 = crud.create(BugCreate(
            title="High severity closed bug",
            description="Test bug",
            project_id="PRJ-000001",
            status="Closed", 
            severity="High",
            created_by="USR-000001"
        ))
        
        # Filter by project + status filter
        open_bugs = crud.list_by_hierarchy(
            project_id="PRJ-000001",
            status=["Open", "New"]
        )
        open_bug_ids = [b.id for b in open_bugs]
        assert bug1.id in open_bug_ids
        assert bug2.id in open_bug_ids
        assert bug3.id not in open_bug_ids
        
        # Filter by project + severity filter
        high_bugs = crud.list_by_hierarchy(
            project_id="PRJ-000001",
            severity=["High"]
        )
        high_bug_ids = [b.id for b in high_bugs]
        assert bug1.id in high_bug_ids
        assert bug2.id not in high_bug_ids
        assert bug3.id in high_bug_ids

    def test_filter_with_priority(self, session):
        """Test filtering with priority filters."""
        seed_user(session)
        seed_hierarchy(session)  # Creates PRJ-000001
        
        crud = BugCRUD(session)
        
        # Create bugs with different priorities
        bug1 = crud.create(BugCreate(
            title="P1 bug",
            description="High priority bug",
            project_id="PRJ-000001",
            priority="P1",
            created_by="USR-000001"
        ))
        
        bug2 = crud.create(BugCreate(
            title="P3 bug",
            description="Low priority bug", 
            project_id="PRJ-000001",
            priority="P3",
            created_by="USR-000001"
        ))
        
        # Filter by priority
        p1_bugs = crud.list_by_hierarchy(
            project_id="PRJ-000001",
            priority=["P1", "P2"]
        )
        p1_bug_ids = [b.id for b in p1_bugs]
        assert bug1.id in p1_bug_ids
        assert bug2.id not in p1_bug_ids

    def test_pagination_with_hierarchy(self, session):
        """Test pagination works with hierarchy filtering."""
        seed_user(session)
        seed_hierarchy(session)  # Creates PRJ-000001
        
        crud = BugCRUD(session)
        
        # Create multiple bugs
        for i in range(5):
            crud.create(BugCreate(
                title=f"Bug {i}",
                description=f"Test bug {i}",
                project_id="PRJ-000001",
                created_by="USR-000001"
            ))
        
        # Test pagination
        page1 = crud.list_by_hierarchy(
            project_id="PRJ-000001",
            skip=0,
            limit=3
        )
        page2 = crud.list_by_hierarchy(
            project_id="PRJ-000001", 
            skip=3,
            limit=3
        )
        
        assert len(page1) == 3
        assert len(page2) == 2
        
        # Ensure no overlap
        page1_ids = [b.id for b in page1]
        page2_ids = [b.id for b in page2]
        assert not set(page1_ids).intersection(set(page2_ids))

    def test_no_hierarchy_filters_returns_all(self, session):
        """Test that calling with no hierarchy filters returns all bugs."""
        seed_user(session)
        seed_hierarchy(session)  # Creates PRJ-000001
        
        crud = BugCRUD(session)
        
        # Create bugs with different setups
        bug1 = crud.create(BugCreate(
            title="Bug 1",
            description="No hierarchy",
            created_by="USR-000001"
        ))
        
        bug2 = crud.create(BugCreate(
            title="Bug 2", 
            description="With project",
            project_id="PRJ-000001",
            created_by="USR-000001"
        ))
        
        # Get all bugs
        all_bugs = crud.list_by_hierarchy()
        bug_ids = [b.id for b in all_bugs]
        
        assert bug1.id in bug_ids
        assert bug2.id in bug_ids

    def test_empty_results_with_nonexistent_hierarchy(self, session):
        """Test filtering by non-existent hierarchy IDs returns empty results."""
        seed_user(session)
        seed_hierarchy(session)  # Creates PRJ-000001
        
        crud = BugCRUD(session)
        
        # Create a bug
        crud.create(BugCreate(
            title="Test bug",
            description="Test",
            project_id="PRJ-000001",
            created_by="USR-000001"
        ))
        
        # Filter by non-existent project
        results = crud.list_by_hierarchy(project_id="PRJ-NONEXISTENT")
        assert len(results) == 0

    def test_combined_filters_work_together(self, session):
        """Test that multiple filters work together correctly."""
        seed_user(session)
        seed_hierarchy(session)  # Creates PRJ-000001
        
        crud = BugCRUD(session)
        
        # Create bugs with various combinations
        matching_bug = crud.create(BugCreate(
            title="Matching bug",
            description="Should match all filters",
            project_id="PRJ-000001",
            status="Open",
            severity="High", 
            priority="P1",
            created_by="USR-000001"
        ))
        
        non_matching_status = crud.create(BugCreate(
            title="Wrong status",
            description="Wrong status",
            project_id="PRJ-000001",
            status="Closed",  # Wrong status
            severity="High",
            priority="P1", 
            created_by="USR-000001"
        ))
        
        non_matching_severity = crud.create(BugCreate(
            title="Wrong severity",
            description="Wrong severity", 
            project_id="PRJ-000001",
            status="Open",
            severity="Low",  # Wrong severity
            priority="P1",
            created_by="USR-000001"
        ))
        
        # Apply all filters
        results = crud.list_by_hierarchy(
            project_id="PRJ-000001",
            status=["Open", "New"],
            severity=["High", "Critical"],
            priority=["P1", "P2"]
        )
        
        result_ids = [b.id for b in results]
        assert matching_bug.id in result_ids
        assert non_matching_status.id not in result_ids
        assert non_matching_severity.id not in result_ids


class TestDescendantFiltering:
    """Test descendant filtering functionality in list_by_hierarchy."""
    
    def test_project_includes_descendants_true(self, session):
        """Test that filtering by project with include_descendants=True includes bugs from all child levels."""
        seed_user(session)
        project, usecase, user_story, task, subtask = seed_hierarchy(session)
        
        crud = BugCRUD(session)
        
        # Create bugs at different hierarchy levels
        project_bug = crud.create(BugCreate(
            title="Project level bug",
            description="Bug at project level",
            project_id="PRJ-000001",
            created_by="USR-000001"
        ))
        
        usecase_bug = crud.create(BugCreate(
            title="Usecase level bug",
            description="Bug at usecase level", 
            usecase_id="UC-000001",
            created_by="USR-000001"
        ))
        
        user_story_bug = crud.create(BugCreate(
            title="User story level bug",
            description="Bug at user story level",
            user_story_id="US-000001", 
            created_by="USR-000001"
        ))
        
        task_bug = crud.create(BugCreate(
            title="Task level bug",
            description="Bug at task level",
            task_id="TSK-000001",
            created_by="USR-000001"
        ))
        
        subtask_bug = crud.create(BugCreate(
            title="Subtask level bug",
            description="Bug at subtask level",
            subtask_id="SUB-000001",
            created_by="USR-000001"
        ))
        
        # Filter by project with descendants
        results = crud.list_by_hierarchy(
            project_id="PRJ-000001", 
            include_descendants=True
        )
        
        result_ids = [b.id for b in results]
        # Should include bugs from all levels
        assert project_bug.id in result_ids
        assert usecase_bug.id in result_ids
        assert user_story_bug.id in result_ids
        assert task_bug.id in result_ids
        assert subtask_bug.id in result_ids
    
    def test_project_includes_descendants_false(self, session):
        """Test that filtering by project with include_descendants=False only includes project-level bugs."""
        seed_user(session)
        project, usecase, user_story, task, subtask = seed_hierarchy(session)
        
        crud = BugCRUD(session)
        
        # Create bugs at different hierarchy levels
        project_bug = crud.create(BugCreate(
            title="Project level bug",
            description="Bug at project level",
            project_id="PRJ-000001",
            created_by="USR-000001"
        ))
        
        usecase_bug = crud.create(BugCreate(
            title="Usecase level bug",
            description="Bug at usecase level",
            usecase_id="UC-000001",
            created_by="USR-000001"
        ))
        
        # Filter by project without descendants
        results = crud.list_by_hierarchy(
            project_id="PRJ-000001",
            include_descendants=False
        )
        
        result_ids = [b.id for b in results]
        # Should only include project-level bug
        assert project_bug.id in result_ids
        assert usecase_bug.id not in result_ids
    
    def test_usecase_includes_descendants_true(self, session):
        """Test that filtering by usecase with include_descendants=True includes bugs from child levels."""
        seed_user(session)
        project, usecase, user_story, task, subtask = seed_hierarchy(session)
        
        crud = BugCRUD(session)
        
        # Create bugs at different hierarchy levels
        project_bug = crud.create(BugCreate(
            title="Project level bug",
            description="Bug at project level",
            project_id="PRJ-000001",
            created_by="USR-000001"
        ))
        
        usecase_bug = crud.create(BugCreate(
            title="Usecase level bug",
            description="Bug at usecase level",
            usecase_id="UC-000001",
            created_by="USR-000001"
        ))
        
        user_story_bug = crud.create(BugCreate(
            title="User story level bug",
            description="Bug at user story level",
            user_story_id="US-000001",
            created_by="USR-000001"
        ))
        
        task_bug = crud.create(BugCreate(
            title="Task level bug", 
            description="Bug at task level",
            task_id="TSK-000001",
            created_by="USR-000001"
        ))
        
        subtask_bug = crud.create(BugCreate(
            title="Subtask level bug",
            description="Bug at subtask level", 
            subtask_id="SUB-000001",
            created_by="USR-000001"
        ))
        
        # Filter by usecase with descendants
        results = crud.list_by_hierarchy(
            usecase_id="UC-000001",
            include_descendants=True
        )
        
        result_ids = [b.id for b in results]
        # Should include usecase and descendant bugs, but not project-level
        assert project_bug.id not in result_ids
        assert usecase_bug.id in result_ids  
        assert user_story_bug.id in result_ids
        assert task_bug.id in result_ids
        assert subtask_bug.id in result_ids
    
    def test_task_includes_descendants_true(self, session):
        """Test that filtering by task with include_descendants=True includes subtask bugs."""
        seed_user(session)
        project, usecase, user_story, task, subtask = seed_hierarchy(session)
        
        crud = BugCRUD(session)
        
        # Create bugs at different levels
        user_story_bug = crud.create(BugCreate(
            title="User story level bug",
            description="Bug at user story level",
            user_story_id="US-000001",
            created_by="USR-000001"
        ))
        
        task_bug = crud.create(BugCreate(
            title="Task level bug",
            description="Bug at task level", 
            task_id="TSK-000001",
            created_by="USR-000001"
        ))
        
        subtask_bug = crud.create(BugCreate(
            title="Subtask level bug",
            description="Bug at subtask level",
            subtask_id="SUB-000001", 
            created_by="USR-000001"
        ))
        
        # Filter by task with descendants
        results = crud.list_by_hierarchy(
            task_id="TSK-000001",
            include_descendants=True
        )
        
        result_ids = [b.id for b in results]
        # Should include task and subtask bugs, but not user story
        assert user_story_bug.id not in result_ids
        assert task_bug.id in result_ids
        assert subtask_bug.id in result_ids
    
    def test_subtask_includes_descendants_behavior(self, session):
        """Test that filtering by subtask behaves consistently (no children below subtask)."""
        seed_user(session)
        project, usecase, user_story, task, subtask = seed_hierarchy(session)
        
        crud = BugCRUD(session)
        
        # Create bugs at different levels  
        task_bug = crud.create(BugCreate(
            title="Task level bug",
            description="Bug at task level",
            task_id="TSK-000001",
            created_by="USR-000001"
        ))
        
        subtask_bug = crud.create(BugCreate(
            title="Subtask level bug", 
            description="Bug at subtask level",
            subtask_id="SUB-000001",
            created_by="USR-000001"
        ))
        
        # Filter by subtask with descendants (should be same as without)
        results_with = crud.list_by_hierarchy(
            subtask_id="SUB-000001",
            include_descendants=True
        )
        
        results_without = crud.list_by_hierarchy(
            subtask_id="SUB-000001", 
            include_descendants=False
        )
        
        # Both should return the same results (only the subtask bug)
        assert len(results_with) == len(results_without) == 1
        assert results_with[0].id == results_without[0].id == subtask_bug.id
        assert task_bug.id not in [b.id for b in results_with]
    
    def test_descendants_with_multiple_branches(self, session):
        """Test descendant filtering works correctly with multiple branches in hierarchy."""
        seed_user(session)
        project = seed_project(session, "PRJ-000001")
        
        # Create two usecases under the same project
        usecase1 = Usecase(id="UC-000001", name="Usecase 1", project_id="PRJ-000001", is_deleted=False)
        usecase2 = Usecase(id="UC-000002", name="Usecase 2", project_id="PRJ-000001", is_deleted=False) 
        session.add_all([usecase1, usecase2])
        
        # Create user stories under each usecase
        user_story1 = UserStory(id="US-000001", name="User Story 1", usecase_id="UC-000001", is_deleted=False)
        user_story2 = UserStory(id="US-000002", name="User Story 2", usecase_id="UC-000002", is_deleted=False)
        session.add_all([user_story1, user_story2])
        session.flush()
        
        crud = BugCRUD(session)
        
        # Create bugs in different branches
        bug_uc1 = crud.create(BugCreate(
            title="Bug in usecase 1", 
            description="Bug",
            usecase_id="UC-000001",
            created_by="USR-000001"
        ))
        
        bug_us1 = crud.create(BugCreate(
            title="Bug in user story 1",
            description="Bug", 
            user_story_id="US-000001",
            created_by="USR-000001"
        ))
        
        bug_us2 = crud.create(BugCreate(
            title="Bug in user story 2",
            description="Bug",
            user_story_id="US-000002", 
            created_by="USR-000001"
        ))
        
        # Filter by project - should include all bugs
        project_results = crud.list_by_hierarchy(
            project_id="PRJ-000001",
            include_descendants=True
        )
        project_ids = [b.id for b in project_results]
        assert bug_uc1.id in project_ids
        assert bug_us1.id in project_ids
        assert bug_us2.id in project_ids
        
        # Filter by usecase1 - should only include bugs from that branch
        uc1_results = crud.list_by_hierarchy(
            usecase_id="UC-000001",
            include_descendants=True
        )
        uc1_ids = [b.id for b in uc1_results]
        assert bug_uc1.id in uc1_ids
        assert bug_us1.id in uc1_ids
        assert bug_us2.id not in uc1_ids  # Different branch