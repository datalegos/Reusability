"""
Alembic env.py for bug-lifecycle-engine.

Reads DATABASE_URL from the environment so no credentials are ever hardcoded.
Only generates migrations against the ``bugs`` table — all other tables are
declared as read-only stubs and must never be altered by this package.
"""

import os
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

# Import the package metadata so autogenerate can detect model changes.
from bug_lifecycle_engine.models import Base

# -----------------------------------------------------------------------
# Alembic Config object (wraps alembic.ini)
# -----------------------------------------------------------------------
config = context.config

# Honour standard Python logging config from alembic.ini, if present.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Override sqlalchemy.url with DATABASE_URL env var — no hardcoded credentials.
database_url = os.environ.get("DATABASE_URL")
if database_url:
    config.set_main_option("sqlalchemy.url", database_url)

target_metadata = Base.metadata

# -----------------------------------------------------------------------
# Tables that this package must NEVER touch — excluded from autogenerate.
# -----------------------------------------------------------------------
READONLY_TABLES = {
    "users",
    "clients",
    "programs",
    "projects",
    "usecases",
    "user_stories",
    "tasks",
    "subtasks",
    "test_runs",
    "test_cases",
    "test_executions",
    "test_case_bugs",
    # Other worky tables this package is unaware of
}


def include_object(obj, name, type_, reflected, compare_to):
    """
    Filter autogenerate to only consider the bugs table.
    Prevents accidental migrations against tables owned by worky.
    """
    if type_ == "table" and name in READONLY_TABLES:
        return False
    return True


# -----------------------------------------------------------------------
# Migration runners
# -----------------------------------------------------------------------


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode (emit SQL to stdout, no live connection)."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        include_object=include_object,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode (live DB connection)."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            include_object=include_object,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
