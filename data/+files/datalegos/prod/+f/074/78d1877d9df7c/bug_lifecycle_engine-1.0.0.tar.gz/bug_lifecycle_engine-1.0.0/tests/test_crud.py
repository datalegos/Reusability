"""
Unit tests for BugCRUD — full lifecycle coverage.
"""

import pytest

from bug_lifecycle_engine.crud import BugCRUD
from bug_lifecycle_engine.schemas import (
    BugCreate,
    BugStatusTransition,
    BugUpdate,
)
from tests.conftest import seed_user, seed_project, seed_test_run


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _payload(**overrides) -> dict:
    defaults = dict(
        title="Login page crashes on submit",
        description="Clicking submit with empty fields causes a 500.",
        status="New",
        created_by="USR-000001",
    )
    defaults.update(overrides)
    return defaults


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------


class TestCreate:
    def test_create_minimal(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        assert bug.id is not None
        assert bug.status == "New"
        assert bug.is_deleted is False
        assert bug.reopen_count == 0

    def test_create_with_classification(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(
            BugCreate(**_payload(category="UI", severity="High", priority="P1"))
        )
        assert bug.category == "UI"
        assert bug.severity == "High"
        assert bug.priority == "P1"

    def test_invalid_status_raises(self, session):
        with pytest.raises(ValueError):
            BugCreate(**_payload(status="Deleted"))

    def test_invalid_severity_raises(self, session):
        with pytest.raises(ValueError):
            BugCreate(**_payload(severity="Extreme"))

    def test_invalid_priority_raises(self, session):
        with pytest.raises(ValueError):
            BugCreate(**_payload(priority="P0"))

    def test_invalid_category_raises(self, session):
        with pytest.raises(ValueError):
            BugCreate(**_payload(category="Hardware"))

    def test_create_linked_to_test_run(self, session):
        seed_user(session)
        seed_test_run(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload(test_run_id="RUN-000001")))
        assert bug.test_run_id == "RUN-000001"


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


class TestRead:
    def test_get_missing_returns_none(self, session):
        assert BugCRUD(session).get("NONE") is None

    def test_get_or_raise_missing(self, session):
        with pytest.raises(ValueError):
            BugCRUD(session).get_or_raise("NONE")

    def test_list_all_pagination(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        for i in range(5):
            crud.create(BugCreate(**_payload(title=f"Bug {i}")))
        p1 = crud.list_all(skip=0, limit=3)
        p2 = crud.list_all(skip=3, limit=3)
        assert len(p1) == 3
        assert len(p2) == 2

    def test_list_by_project(self, session):
        seed_user(session)
        seed_project(session)
        crud = BugCRUD(session)
        crud.create(BugCreate(**_payload(project_id="PRJ-000001")))
        crud.create(BugCreate(**_payload(project_id="PRJ-000001")))
        crud.create(BugCreate(**_payload()))  # no project
        results = crud.list_by_project("PRJ-000001")
        assert len(results) == 2

    def test_list_by_status(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        crud.create(BugCreate(**_payload()))
        results = crud.list_by_status("New")
        assert len(results) >= 1

    def test_list_excludes_soft_deleted(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        crud.soft_delete(bug.id, "USR-000001")
        results = crud.list_all(include_deleted=False)
        assert all(r.id != bug.id for r in results)

    def test_count_by_status(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        crud.create(BugCreate(**_payload()))
        counts = crud.count_by_status()
        assert counts.get("New", 0) >= 1


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------


class TestUpdate:
    def test_partial_update(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        updated = crud.update(bug.id, BugUpdate(title="Renamed", updated_by="USR-000001"))
        assert updated.title == "Renamed"
        assert updated.status == "New"  # unchanged

    def test_assign(self, session):
        seed_user(session)
        seed_user(session, "DEV-000001")
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        crud.assign(bug.id, "DEV-000001", "USR-000001")
        assert bug.assignee_id == "DEV-000001"

    def test_set_qa_owner(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        crud.set_qa_owner(bug.id, "USR-000001", "USR-000001")
        assert bug.qa_owner_id == "USR-000001"


# ---------------------------------------------------------------------------
# Status transitions
# ---------------------------------------------------------------------------


class TestTransition:
    def _transition(self, session, bug, new_status: str):
        return BugCRUD(session).transition(
            bug.id,
            BugStatusTransition(new_status=new_status, updated_by="USR-000001"),
        )

    def test_new_to_open(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        self._transition(session, bug, "Open")
        assert bug.status == "Open"

    def test_full_happy_path(self, session):
        """New → Open → In Progress → Fixed → In Review → Ready for QA → Verified → Closed"""
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))

        for step in ("Open", "In Progress", "Fixed", "In Review", "Ready for QA", "Verified", "Closed"):
            self._transition(session, bug, step)

        assert bug.status == "Closed"
        assert bug.closed_at is not None
        
        # Verify status history was created for each transition
        from bug_lifecycle_engine.crud import BugStatusHistoryCRUD
        history_crud = BugStatusHistoryCRUD(session)
        history = history_crud.list_by_bug(bug.id)
        assert len(history) == 7  # All 7 transitions should be recorded

    def test_close_sets_closed_at(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        self._transition(session, bug, "Open")
        self._transition(session, bug, "Closed")
        assert bug.closed_at is not None

    def test_reopen_increments_count_and_clears_closed_at(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        self._transition(session, bug, "Open")
        self._transition(session, bug, "Closed")
        self._transition(session, bug, "Reopened")
        assert bug.reopen_count == 1
        assert bug.closed_at is None
        assert bug.status == "Reopened"

    def test_invalid_transition_raises(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        # New → Verified is not allowed
        with pytest.raises(ValueError, match="Cannot transition"):
            self._transition(session, bug, "Verified")

    def test_new_to_closed_allowed(self, session):
        """New → Closed is a valid shortcut (e.g. duplicate/not-a-bug)."""
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        self._transition(session, bug, "Closed")
        assert bug.status == "Closed"

    def test_transition_on_deleted_bug_raises(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        crud.soft_delete(bug.id, "USR-000001")
        with pytest.raises(ValueError, match="not found"):
            self._transition(session, bug, "Open")

    def test_resolution_notes_set_on_transition(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        crud.transition(
            bug.id,
            BugStatusTransition(
                new_status="Closed",
                updated_by="USR-000001",
                resolution_notes="Duplicate of BUG-000042",
            ),
        )
        assert bug.resolution_notes == "Duplicate of BUG-000042"


# ---------------------------------------------------------------------------
# Soft delete
# ---------------------------------------------------------------------------


class TestSoftDelete:
    def test_soft_delete(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        crud.soft_delete(bug.id, "USR-000001")
        assert bug.is_deleted is True

    def test_soft_deleted_row_still_fetchable(self, session):
        seed_user(session)
        crud = BugCRUD(session)
        bug = crud.create(BugCreate(**_payload()))
        crud.soft_delete(bug.id, "USR-000001")
        fetched = crud.get(bug.id)
        assert fetched is not None
        assert fetched.is_deleted is True
