"""
Database and application settings resolved from environment variables and config files.
No defaults for credentials — startup fails fast if they are absent.
"""

import yaml
from functools import lru_cache
from pathlib import Path
from typing import List, Optional
from pydantic import BaseModel
from pydantic_settings import BaseSettings


class CORSSettings(BaseModel):
    origins: List[str]
    credentials: bool = True
    methods: List[str] = ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
    headers: List[str] = ["*"]


class AppSettings(BaseModel):
    port: int = 8010
    host: str = "0.0.0.0"
    cors: CORSSettings
    log_level: str = "INFO"


class AuthSettings(BaseModel):
    api_key_header: str = "X-API-Key"
    required: bool = True


class PaginationSettings(BaseModel):
    default_limit: int = 50
    max_limit: int = 100


class BugSettings(BaseModel):
    default_status: str = "New"
    default_priority: str = "P3"
    default_severity: str = "Medium"
    enforce_transitions: bool = True
    comment_edit_window_minutes: int = 15


class TestSettings(BaseModel):
    default_execution_timeout_minutes: int = 30
    auto_create_bugs_on_failure: bool = True


class AppConfig(BaseModel):
    app: AppSettings
    auth: AuthSettings
    pagination: PaginationSettings
    bugs: BugSettings
    tests: TestSettings


class DatabaseSettings(BaseSettings):
    DATABASE_HOST: str
    DATABASE_PORT: int = 5432
    DATABASE_NAME: str
    DATABASE_USER: str
    DATABASE_PASSWORD: str
    DATABASE_POOL_SIZE: int = 5
    DATABASE_MAX_OVERFLOW: int = 10
    
    # App settings from env vars
    APP_PORT: int = 8010
    LOG_LEVEL: str = "INFO"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"

    @property
    def database_url(self) -> str:
        return (
            f"postgresql+psycopg2://"
            f"{self.DATABASE_USER}:{self.DATABASE_PASSWORD}"
            f"@{self.DATABASE_HOST}:{self.DATABASE_PORT}"
            f"/{self.DATABASE_NAME}"
        )


def load_app_config(config_path: Optional[str] = None) -> AppConfig:
    """Load application configuration from YAML file."""
    if config_path is None:
        # Try multiple possible locations for config.yml
        possible_paths = [
            Path(__file__).parent.parent.parent.parent / "config.yml",  # Development
            Path("/app/config.yml"),  # Docker container
            Path.cwd() / "config.yml",  # Current working directory
        ]
        
        config_path = None
        for path in possible_paths:
            if path.exists():
                config_path = path
                break
        
        if config_path is None:
            raise FileNotFoundError(f"Config file not found in any of these locations: {[str(p) for p in possible_paths]}")
    
    if not Path(config_path).exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    
    with open(config_path, 'r', encoding='utf-8') as f:
        config_data = yaml.safe_load(f)
    
    return AppConfig(**config_data)


# Lazy initialization factories

@lru_cache
def get_settings() -> DatabaseSettings:
    """Get database settings instance. Cached after first call."""
    return DatabaseSettings()  # type: ignore[call-arg]


@lru_cache
def get_app_config(config_path: Optional[str] = None) -> AppConfig:
    """Get application config instance. Cached after first call."""
    return load_app_config(config_path)
