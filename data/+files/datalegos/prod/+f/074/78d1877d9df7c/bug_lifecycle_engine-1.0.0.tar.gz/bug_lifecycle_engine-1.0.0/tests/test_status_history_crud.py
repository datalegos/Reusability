"""
Tests for BugStatusHistoryCRUD operations and automatic history creation.
"""

import pytest

from bug_lifecycle_engine.crud import BugCRUD, BugStatusHistoryCRUD
from bug_lifecycle_engine.schemas import BugCreate, BugStatusTransition
from tests.conftest import seed_user


class TestBugStatusHistoryCRUD:
    """Test status history CRUD and automatic creation."""

    def test_list_status_history_empty(self, session):
        """Test listing history for a bug with no transitions."""
        seed_user(session)
        
        bug_crud = BugCRUD(session)
        bug = bug_crud.create(BugCreate(
            title="Test bug",
            description="Test description",
            created_by="USR-000001"
        ))
        
        history_crud = BugStatusHistoryCRUD(session)
        history = history_crud.list_by_bug(bug.id)
        
        # No manual transitions yet, but creation should create initial history
        assert len(history) >= 0  # Depends on if we auto-create for "New" status

    def test_automatic_history_creation_on_transition(self, session):
        """Test that status transitions automatically create history records."""
        seed_user(session)
        
        bug_crud = BugCRUD(session)
        history_crud = BugStatusHistoryCRUD(session)
        
        # Create a bug
        bug = bug_crud.create(BugCreate(
            title="Test bug",
            description="Test description", 
            created_by="USR-000001"
        ))
        
        # Perform a transition
        bug_crud.transition(bug.id, BugStatusTransition(
            new_status="Open",
            updated_by="USR-000001",
            resolution_notes="Opening for investigation"
        ))
        
        # Check that history was created
        history = history_crud.list_by_bug(bug.id)
        assert len(history) >= 1
        
        # Find the transition record
        transition_record = None
        for record in history:
            if record.from_status == "New" and record.to_status == "Open":
                transition_record = record
                break
        
        assert transition_record is not None
        assert transition_record.from_status == "New"
        assert transition_record.to_status == "Open"
        assert transition_record.changed_by == "USR-000001"
        assert transition_record.resolution_notes == "Opening for investigation"
        assert transition_record.changed_at is not None

    def test_full_workflow_history_tracking(self, session):
        """Test complete bug workflow with history tracking."""
        seed_user(session)
        seed_user(session, "DEV-000001")
        
        bug_crud = BugCRUD(session)
        history_crud = BugStatusHistoryCRUD(session)
        
        # Create bug
        bug = bug_crud.create(BugCreate(
            title="Workflow test bug",
            description="Testing full workflow",
            created_by="USR-000001"
        ))
        
        # Perform workflow: New → Open → In Progress → Fixed → Closed
        transitions = [
            ("Open", "USR-000001", "Triaging bug"),
            ("In Progress", "DEV-000001", "Starting work on fix"),
            ("Fixed", "DEV-000001", "Implemented fix in commit abc123"),
            ("Closed", "USR-000001", "Verified fix works correctly")
        ]
        
        for new_status, user, notes in transitions:
            bug_crud.transition(bug.id, BugStatusTransition(
                new_status=new_status,
                updated_by=user,
                resolution_notes=notes
            ))
        
        # Verify complete history
        history = history_crud.list_by_bug(bug.id)
        assert len(history) == 4  # All 4 transitions
        
        # Verify all expected statuses are present
        statuses = [h.to_status for h in history]
        expected_statuses = {"Closed", "Fixed", "In Progress", "Open"}
        assert set(statuses) == expected_statuses
        
        # Find the final "Closed" record and verify it
        closed_record = None
        for record in history:
            if record.to_status == "Closed":
                closed_record = record
                break
        
        assert closed_record is not None
        assert closed_record.from_status == "Fixed"
        assert closed_record.changed_by == "USR-000001"
        assert "Verified fix works" in closed_record.resolution_notes

    def test_reopen_history_tracking(self, session):
        """Test that reopening creates proper history records."""
        seed_user(session)
        
        bug_crud = BugCRUD(session)
        history_crud = BugStatusHistoryCRUD(session)
        
        # Create and close a bug
        bug = bug_crud.create(BugCreate(
            title="Reopen test",
            description="Testing reopen workflow",
            created_by="USR-000001"
        ))
        
        bug_crud.transition(bug.id, BugStatusTransition(
            new_status="Closed",
            updated_by="USR-000001",
            resolution_notes="Fixed"
        ))
        
        bug_crud.transition(bug.id, BugStatusTransition(
            new_status="Reopened", 
            updated_by="USR-000001",
            resolution_notes="Issue persists"
        ))
        
        # Check history includes both close and reopen
        history = history_crud.list_by_bug(bug.id)
        assert len(history) == 2
        
        # Find the reopen record (should have to_status="Reopened")
        reopen_record = None
        for record in history:
            if record.to_status == "Reopened":
                reopen_record = record
                break
        
        assert reopen_record is not None
        assert reopen_record.from_status == "Closed"
        assert reopen_record.to_status == "Reopened"
        assert reopen_record.resolution_notes == "Issue persists"

    def test_history_pagination(self, session):
        """Test pagination of status history."""
        seed_user(session)
        
        bug_crud = BugCRUD(session)
        history_crud = BugStatusHistoryCRUD(session)
        
        # Create bug
        bug = bug_crud.create(BugCreate(
            title="Pagination test",
            description="Testing history pagination",
            created_by="USR-000001"
        ))
        
        # Create many transitions
        statuses = ["Open", "In Progress", "Fixed", "Closed", "Reopened", "Open"]
        for status in statuses:
            bug_crud.transition(bug.id, BugStatusTransition(
                new_status=status,
                updated_by="USR-000001"
            ))
        
        # Test pagination
        page1 = history_crud.list_by_bug(bug.id, skip=0, limit=3)
        page2 = history_crud.list_by_bug(bug.id, skip=3, limit=3)
        
        assert len(page1) == 3
        assert len(page2) == 3  # Remaining transitions
        
        # Ensure no overlap
        page1_ids = [h.id for h in page1]
        page2_ids = [h.id for h in page2]
        assert not set(page1_ids).intersection(set(page2_ids))

    def test_get_specific_history_record(self, session):
        """Test getting a specific history record by ID."""
        seed_user(session)
        
        bug_crud = BugCRUD(session)
        history_crud = BugStatusHistoryCRUD(session)
        
        # Create bug and transition
        bug = bug_crud.create(BugCreate(
            title="Get test",
            description="Testing get history",
            created_by="USR-000001"
        ))
        
        bug_crud.transition(bug.id, BugStatusTransition(
            new_status="Open",
            updated_by="USR-000001"
        ))
        
        # Get the history record
        history = history_crud.list_by_bug(bug.id)
        assert len(history) == 1
        
        record_id = history[0].id
        fetched_record = history_crud.get(record_id)
        
        assert fetched_record is not None
        assert fetched_record.id == record_id
        assert fetched_record.to_status == "Open"

    def test_nonexistent_history_record(self, session):
        """Test getting non-existent history record."""
        history_crud = BugStatusHistoryCRUD(session)
        
        result = history_crud.get("NONEXISTENT")
        assert result is None

    def test_invalid_status_validation(self, session):
        """Test that invalid statuses are rejected in history records."""
        # This is primarily tested via the BugStatusHistory model validators
        # and the BugCRUD transition validation, but we can test the model directly
        from bug_lifecycle_engine.models import BugStatusHistory
        
        with pytest.raises(ValueError, match="must be one of"):
            BugStatusHistory(
                bug_id="BUG-123",
                from_status="InvalidStatus",
                to_status="New",
                changed_by="USR-000001"
            )