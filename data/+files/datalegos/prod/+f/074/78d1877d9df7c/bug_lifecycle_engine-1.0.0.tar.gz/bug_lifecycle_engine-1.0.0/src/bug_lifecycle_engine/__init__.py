"""
bug-lifecycle-engine
====================
Full bug lifecycle management against the existing worky ``bugs`` table.

Quick start::

    from bug_lifecycle_engine import get_engine, get_session
    from bug_lifecycle_engine.crud import BugCRUD

    engine = get_engine()
    with get_session(engine) as session:
        crud = BugCRUD(session)
        bug = crud.get("BUG-000001")
        crud.transition(bug.id, "Open", by="USR-000001")
"""

from .db import get_engine, get_session  # noqa: F401

__version__ = "1.0.0"
__all__ = ["get_engine", "get_session"]
