"""
Single source of truth for all domain constants used by bug-lifecycle-engine.

These mirror the validated values from the worky bugs table exactly.
Any future additive extensions belong here first, then in a migration.
"""

# Bug status workflow — ordered by typical lifecycle progression
BUG_STATUSES = (
    "New",
    "Open",
    "In Progress",
    "Fixed",
    "In Review",
    "Ready for QA",
    "Verified",
    "Closed",
    "Reopened",
)

# Valid transitions: maps current status → set of allowed next statuses
# This encodes the QA workflow rules in one place.
BUG_STATUS_TRANSITIONS: dict[str, tuple[str, ...]] = {
    "New":          ("Open", "Closed"),
    "Open":         ("In Progress", "Closed"),
    "In Progress":  ("Fixed", "Closed"),
    "Fixed":        ("In Review", "Closed"),
    "In Review":    ("Ready for QA", "In Progress"),
    "Ready for QA": ("Verified", "Reopened"),
    "Verified":     ("Closed", "Reopened"),
    "Closed":       ("Reopened",),
    "Reopened":     ("Open", "In Progress"),
}

BUG_SEVERITIES = ("Critical", "High", "Medium", "Low")

BUG_PRIORITIES = ("P1", "P2", "P3", "P4")

BUG_CATEGORIES = (
    "UI",
    "Backend",
    "Database",
    "Integration",
    "Performance",
    "Security",
    "Environment",
)
