"""
Pydantic v2 schemas for bug-lifecycle-engine.
Input validation and serialised output — decoupled from the ORM layer.
"""

from __future__ import annotations

from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from .constants import BUG_CATEGORIES, BUG_PRIORITIES, BUG_SEVERITIES, BUG_STATUSES

# Build Literal types from the constants tuples so validation is DRY.
BugStatus = Literal[
    "New", "Open", "In Progress", "Fixed", "In Review",
    "Ready for QA", "Verified", "Closed", "Reopened"
]
BugSeverity = Literal["Critical", "High", "Medium", "Low"]
BugPriority = Literal["P1", "P2", "P3", "P4"]
BugCategory = Literal[
    "UI", "Backend", "Database", "Integration",
    "Performance", "Security", "Environment"
]


class BugBase(BaseModel):
    title: str = Field(..., max_length=255)
    description: str

    # Classification
    category: Optional[BugCategory] = None
    severity: BugSeverity = "Medium"
    priority: BugPriority = "P2"
    status: BugStatus = "New"

    # Assignments
    reporter_id: Optional[str] = Field(None, max_length=20)
    assignee_id: Optional[str] = Field(None, max_length=20)
    qa_owner_id: Optional[str] = Field(None, max_length=20)

    # Reproduction
    reproduction_steps: Optional[str] = None
    expected_result: Optional[str] = None
    actual_result: Optional[str] = None

    # Linked items
    linked_task_id: Optional[str] = Field(None, max_length=20)
    linked_commit: Optional[str] = Field(None, max_length=255)
    linked_pr: Optional[str] = Field(None, max_length=255)

    # Additional
    component_attached_to: Optional[str] = Field(None, max_length=255)
    environment: Optional[str] = Field(None, max_length=255)
    resolution_notes: Optional[str] = None

    # Legacy fields for backward compatibility
    reported_by: Optional[str] = Field(None, max_length=20)
    assigned_to: Optional[str] = Field(None, max_length=20)
    found_in_version: Optional[str] = Field(None, max_length=50)
    fixed_in_version: Optional[str] = Field(None, max_length=50)
    browser: Optional[str] = Field(None, max_length=50)
    os: Optional[str] = Field(None, max_length=50)
    device_type: Optional[str] = Field(None, max_length=50)

    # QA origin (set when bug discovered via a test run/case)
    test_run_id: Optional[str] = Field(None, max_length=20)
    test_case_id: Optional[str] = Field(None, max_length=20)

    # Hierarchy (at most one should be set)
    client_id: Optional[str] = Field(None, max_length=20)
    program_id: Optional[str] = Field(None, max_length=20)
    project_id: Optional[str] = Field(None, max_length=20)
    usecase_id: Optional[str] = Field(None, max_length=20)
    user_story_id: Optional[str] = Field(None, max_length=20)
    task_id: Optional[str] = Field(None, max_length=20)
    subtask_id: Optional[str] = Field(None, max_length=20)


class BugCreate(BugBase):
    created_by: Optional[str] = Field(None, max_length=255)
    updated_by: Optional[str] = Field(None, max_length=255)
    entity_type: str = Field(default="Task", max_length=50)
    entity_id: Optional[str] = Field(None, max_length=20)


class BugUpdate(BaseModel):
    """Partial update — only supplied fields are changed."""

    title: Optional[str] = Field(None, max_length=255)
    description: Optional[str] = None
    category: Optional[BugCategory] = None
    severity: Optional[BugSeverity] = None
    priority: Optional[BugPriority] = None
    reporter_id: Optional[str] = Field(None, max_length=20)
    assignee_id: Optional[str] = Field(None, max_length=20)
    qa_owner_id: Optional[str] = Field(None, max_length=20)
    reproduction_steps: Optional[str] = None
    expected_result: Optional[str] = None
    actual_result: Optional[str] = None
    linked_task_id: Optional[str] = Field(None, max_length=20)
    linked_commit: Optional[str] = Field(None, max_length=255)
    linked_pr: Optional[str] = Field(None, max_length=255)
    component_attached_to: Optional[str] = Field(None, max_length=255)
    environment: Optional[str] = Field(None, max_length=255)
    resolution_notes: Optional[str] = None
    found_in_version: Optional[str] = Field(None, max_length=50)
    fixed_in_version: Optional[str] = Field(None, max_length=50)
    browser: Optional[str] = Field(None, max_length=50)
    os: Optional[str] = Field(None, max_length=50)
    device_type: Optional[str] = Field(None, max_length=50)
    updated_by: Optional[str] = Field(None, max_length=255)


class BugStatusTransition(BaseModel):
    """Used by the transition endpoint — validates only the new status and actor."""

    new_status: BugStatus
    updated_by: str = Field(..., max_length=255)
    resolution_notes: Optional[str] = None


class BugRead(BugBase):
    model_config = ConfigDict(from_attributes=True)

    id: str
    entity_type: str
    entity_id: str
    reopen_count: int
    found_in_version: Optional[str] = None
    fixed_in_version: Optional[str] = None
    browser: Optional[str] = None
    os: Optional[str] = None
    device_type: Optional[str] = None
    created_by: Optional[str] = None
    updated_by: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    closed_at: Optional[datetime] = None
    is_deleted: bool


class BugListItem(BaseModel):
    """Lightweight projection for list responses."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    title: str
    status: str
    severity: Optional[str] = None
    priority: Optional[str] = None
    assignee_id: Optional[str] = None
    created_at: datetime
    is_deleted: bool


# ---------------------------------------------------------------------------
# Comment Schemas
# ---------------------------------------------------------------------------

class CommentCreate(BaseModel):
    """Schema for creating a new comment."""
    comment_text: str = Field(..., min_length=1, max_length=10000)
    mentioned_users: Optional[List[str]] = Field(default=None, description="List of user IDs mentioned in the comment")
    attachments: Optional[List[str]] = Field(default=None, description="List of attachment file references")


class CommentUpdate(BaseModel):
    """Schema for updating a comment (text only, within 15 minutes)."""
    comment_text: str = Field(..., min_length=1, max_length=10000)


class CommentResponse(BaseModel):
    """Schema for comment responses."""
    model_config = ConfigDict(from_attributes=True)

    id: str
    bug_id: str
    comment_text: str
    author_id: str
    mentioned_users: Optional[List[str]] = None
    attachments: Optional[List[str]] = None
    is_edited: bool
    edited_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    is_deleted: bool

    @classmethod
    def from_orm_with_json_parsing(cls, obj: "BugComment") -> "CommentResponse":
        """Convert ORM object to response, parsing JSON fields."""
        import json
        
        data = {
            "id": obj.id,
            "bug_id": obj.bug_id,
            "comment_text": obj.comment_text,
            "author_id": obj.author_id,
            "is_edited": obj.is_edited,
            "edited_at": obj.edited_at,
            "created_at": obj.created_at,
            "updated_at": obj.updated_at,
            "is_deleted": obj.is_deleted,
        }
        
        # Parse JSON fields
        if obj.mentioned_users:
            try:
                data["mentioned_users"] = json.loads(obj.mentioned_users)
            except (json.JSONDecodeError, TypeError):
                data["mentioned_users"] = []
        
        if obj.attachments:
            try:
                data["attachments"] = json.loads(obj.attachments)
            except (json.JSONDecodeError, TypeError):
                data["attachments"] = []
        
        return cls(**data)


# ---------------------------------------------------------------------------
# Attachment Schemas
# ---------------------------------------------------------------------------

class AttachmentCreate(BaseModel):
    """Schema for creating a new attachment."""
    file_name: str = Field(..., max_length=255)
    file_path: str = Field(..., max_length=500)
    file_type: Optional[str] = Field(None, max_length=50, description="MIME type")
    file_size: Optional[int] = Field(None, description="File size in bytes")


class AttachmentResponse(BaseModel):
    """Schema for attachment responses."""
    model_config = ConfigDict(from_attributes=True)

    id: str
    bug_id: str
    file_name: str
    file_path: str
    file_type: Optional[str] = None
    file_size: Optional[int] = None
    uploaded_by: str
    uploaded_at: datetime
    is_deleted: bool


# ---------------------------------------------------------------------------
# Status History Schemas
# ---------------------------------------------------------------------------

class BugStatusHistoryResponse(BaseModel):
    """Schema for bug status history responses."""
    model_config = ConfigDict(from_attributes=True)

    id: str
    bug_id: str
    from_status: Optional[str] = None
    to_status: str
    resolution_notes: Optional[str] = None
    changed_by: str
    changed_at: datetime
